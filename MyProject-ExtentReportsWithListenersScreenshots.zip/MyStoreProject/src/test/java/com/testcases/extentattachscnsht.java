package com.testcases;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.mystore.actiondriver.Action;
import com.mystore.base.BaseClass;
import com.mystore.utility.ExtentManager;
import com.mystore.utility.Log;


@Listeners(com.mystore.utility.ListenerClass.class)

public class extentattachscnsht extends BaseClass{
	Action action1= new Action();
	public WebDriver driver;
	public BaseClass action;
	public final static String reportLocation  = System.getProperty("user.dir")+"/Reports/Automation_Reports_" + (new Date()).toString().replace(":", "_").replace(" ", "_");
	@BeforeSuite
	public void setUp() throws Exception {
		//ExtentReport.startReport();
		driver = getDriver();
		launchApp("Chrome");	
	}
	
	
	//---first try
	// This works but we need to create screenshot method inside class
	@Test(priority = 1)
	public void login1() throws Exception{
		ExtentManager.test.assignCategory("Google");
		getDriver().get("https://www.google.com");
		Log.logAndConsole("Google opened");
		action1.generatePassReportWithScreenShot("Google");
	}
	
	@Test(priority = 1)
	public void login2() throws Exception{
		ExtentManager.test.assignCategory("YouTube");
		getDriver().get("https://www.youtube.com");
		Log.logAndConsole("YouTube opened");
		action1.generatePassReportWithScreenShot("Youtube");
	}
	
	@AfterClass
	public void close() throws IOException {
		getDriver().close();
		
	}
	
	public String getScreenshotPath() throws Exception {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		File source= ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		//String path=System.getProperty("user.dir")+"/Screenshots/screenshot+"+dateName+".png";
		String path=reportLocation+"/ScreenShots/screenshot+"+dateName+".png";
		//String path=reportLocation + "\\ScreenShots\\" + "screenshot" + String.valueOf(System.nanoTime()) + dateName + ".png";
		FileUtils.copyFile(source, new File(path));
		return path;
	}
	
	public String getScreenshotasBase64() throws Exception {
		File source= ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		String path=System.getProperty("user.dir")+"/Screenshots/image.png";
		FileUtils.copyFile(source, new File(path));
		byte[] imageBytes = IOUtils.toByteArray(new FileInputStream(path));
		
		return Base64.getEncoder().encodeToString(imageBytes);
	}
	
	public String getScrnshtasBase64() {
		return ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.BASE64);
	}
	
	public String getScreenshot() {
		String destination = null;
		String newImageString = null;
		try {
			String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
			TakesScreenshot ts = (TakesScreenshot) getDriver();
			File source = ts.getScreenshotAs(OutputType.FILE);
			destination = reportLocation + "\\ScreenShots\\" + "screenshot" + String.valueOf(System.nanoTime()) + dateName + ".png";
			File finalDestination = new File(destination);
			FileUtils.copyFile(source, finalDestination);
			newImageString = "http://localhost:8082/job/MyStoreProject/ws/MyStoreProject/ScreenShots/" + "screenshot" + "_"
					+ dateName + ".png";
		} catch (Exception e) {
		}
		
		return newImageString;
	}
	
}