package com.mystore.testcases;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.mystore.base.BaseClass;
import com.mystore.utility.ExtentManager;

@Listeners(com.mystore.utility.ListenerClass.class)

public class Report extends BaseClass{
	
	public WebDriver driver;
	public BaseClass action;
	
	@BeforeSuite
	public void setUp() throws Exception {
		//ExtentReport.startReport();
		driver = getDriver();
		launchApp("Chrome");	
	}

		@BeforeTest
		public void Login() { // This block is for Login method
			getDriver().get(
					"https://selfservetst.adb.org/OA_HTML/RF.jsp?function_id=31549&resp_id=-1&resp_appl_id=-1&security_group_id=0&lang_code=US&oas=JyjBWRUW5F3Onyf4SLatCQ..&params=y7NM-whTl8VKOg3FaPO9EagP1MB5tCIbSjH24MYQ88tmSeI3c9ElI0SNDd.mOw.n");
			getDriver().manage().window().maximize();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			getDriver().findElement(By.id("unamebean")).sendKeys("Lnasi");
			getDriver().findElement(By.id("pwdbean")).sendKeys("testuser1234");
			getDriver().findElement(By.id("SubmitButton")).click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// driver.findElement(By.cssSelector("a[href*='https://selfservetst.adb.org/OA_HTML/OA.jsp?OAFunc=OAHOMEPAGE&akRegionApplicationId=0&navRespId=50810&navRespAppId=20043&navSecGrpId=0&transactionid=1601091671&oapc=2&oas=bROBybzOUc-D--0yvQ39ag..']")).click();
		}
		
		@BeforeMethod
		public void testStart() {
			System.out.println("Test execution is started");
			
		}

		@Test(priority = 1, testName = "4.6.1-VolumeReport")
		public void testcase_4_6_1() {
			System.out.println(" Test case-4.6.1");
			ExtentManager.test.log(Status.INFO, "Test case-4.6.1 Started");
			// clicking on ADB TD Payments Administrator
			getDriver().findElement(By.xpath("//*[contains(text(), 'ADB TD Payments Administrator')]")).click();

			scrolltoObject(By.id("N442"), "ADB Processed Disbursement Voucher Volume Report");

			// clicking on ADB Processed Disbursement Voucher Volume Report
			getDriver().findElement(By.id("N442")).click();

			// Processed date
						type(By.id("N310"), "09-May-2022");
						
						// Processed date to
						type(By.id("N311"), "09-May-2022");
			
			// Clicking on continue
			getDriver().findElement(By.xpath("(//button[@title='Continue'])[1]")).click();

			// Clicking on Submit
			getDriver().findElement(By.id("FndReqSubmit")).click();

			// Clicking on Ok button
			getDriver().findElement(By.xpath("//button[@title='&OK']")).click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			// Clicking on Refresh button
			getDriver().findElement(By.id("Refresh_uixr")).click();

			// Click on Details
			if (getDriver().findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
				String Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
						.getAttribute("textContent");
				boolean flag = false;
				while (!flag) {
					if (Phse == null) {
						getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						getDriver().findElement(By.id("Refresh_uixr")).click();
						Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
								.getAttribute("textContent");
					} else if (Phse.contains("Completed")) {
						System.out.println(Phse);
						flag = true;
						break;
					} else {
						getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
						getDriver().findElement(By.id("Refresh_uixr")).click();
						Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
								.getAttribute("textContent");
					}
				}
			}
			waitForElement(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"));
			click(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"), "Details");
			click(By.xpath("//*[@id=\"paraHideShow\"]/div/a"), "show");
						
			System.out.println("==================Test case completed==================");
			ExtentManager.test.log(Status.INFO, "Test case completed");

		}

		@Test(priority = 2, testName = "4.6.2--pdf direct")
		public void testcase_4_6_2() {
			System.out.println(" Test case-4.6.2");
			getDriver().findElement(By.xpath("//*[contains(text(), 'Home')]")).click();
			// clicking on ADB TD Payments Administrator
			getDriver().findElement(By.xpath("//*[contains(text(), 'ADB TD Payments Administrator')]")).click();

			scrolltoObject(By.id("N442"), "ADB Processed Disbursement Voucher Volume Report");

			// clicking on ADB Processed Disbursement Vouchers Report
			getDriver().findElement(By.id("N442")).click();

			// Processed date
			type(By.id("N310"), "09-May-2022");
			
			// Processed date to
			type(By.id("N311"), "09-May-2022");

			// select PDF format
			// Clicking on continue
			getDriver().findElement(By.xpath("(//button[@title='Continue'])[1]")).click();

			// Clicking on Submit
			getDriver().findElement(By.id("FndReqSubmit")).click();

			// Clicking on Ok button
			getDriver().findElement(By.xpath("//button[@title='&OK']")).click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			// Clicking on details
						if (getDriver().findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
							String Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
									.getAttribute("textContent");
							boolean flag = false;
							while (!flag) {
								if (Phse == null) {
									getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									getDriver().findElement(By.id("Refresh_uixr")).click();
									Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
											.getAttribute("textContent");
								} else if (Phse.contains("Completed")) {
									System.out.println(Phse);
									flag = true;
									break;
								} else {
									getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									getDriver().findElement(By.id("Refresh_uixr")).click();
									Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
											.getAttribute("textContent");
								}
							}
						}
						waitForElement(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"));
						click(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"), "Details");
						
						//back to req
						click(By.xpath("//a[@id='ReturnToRequests']"), "back");
						
						click(By.xpath("//a[@id='N3:item111:0']//img"), "Republish");
						
						type(By.xpath("//input[@id='Fndcplayformatname']"), "PDF");
						
						click(By.xpath("//button[@id='SaveButton_uixr']"), "Apply");
						
						click(By.xpath("//button[@id='OKButton']"), "Ok");
						
						// Block for validation of Phase status and Output
						if (getDriver().findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
							String Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
									.getAttribute("textContent");
							boolean flag = false;
							while (!flag) {
								if (Phse == null) {
									getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									getDriver().findElement(By.id("Refresh_uixr")).click();
									Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
											.getAttribute("textContent");
								} else if (Phse.contains("Completed")) {
									System.out.println(Phse);
									flag = true;
									break;
								} else {
									getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									getDriver().findElement(By.id("Refresh_uixr")).click();
									Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
											.getAttribute("textContent");
								}
							}
						}
						waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
						click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");

						getDriver().findElement(By.id("Refresh_uixr")).click();
						getDriver().manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
						
						System.out.println("==================Test case completed==================");
		}

		@Test(priority = 3, testName = "4.6.3-excel")
		public void testcase_4_6_3() {
			System.out.println(" Test case-4.6.3");
			getDriver().findElement(By.xpath("//*[contains(text(), 'Home')]")).click();
			// clicking on ADB TD Payments Administrator
			getDriver().findElement(By.xpath("//*[contains(text(), 'ADB TD Payments Administrator')]")).click();

			scrolltoObject(By.id("N442"), "ADB Processed Disbursement Voucher Volume Report");

			// clicking on ADB Processed Disbursement Vouchers Report
			getDriver().findElement(By.id("N442")).click();

			// Processed date
			type(By.id("N310"), "09-May-2022");
			
			// Processed date to
			type(By.id("N311"), "09-May-2022");

			// Clicking on continue
			getDriver().findElement(By.xpath("(//button[@title='Continue'])[1]")).click();

			// Clicking on Submit
			getDriver().findElement(By.id("FndReqSubmit")).click();

			// Clicking on Ok button
			getDriver().findElement(By.xpath("//button[@title='&OK']")).click();
			getDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			// Clicking on details
						if (getDriver().findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
							String Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
									.getAttribute("textContent");
							boolean flag = false;
							while (!flag) {
								if (Phse == null) {
									getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									getDriver().findElement(By.id("Refresh_uixr")).click();
									Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
											.getAttribute("textContent");
								} else if (Phse.contains("Completed")) {
									System.out.println(Phse);
									flag = true;
									break;
								} else {
									getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									getDriver().findElement(By.id("Refresh_uixr")).click();
									Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
											.getAttribute("textContent");
								}
							}
						}
						waitForElement(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"));
						click(By.xpath("//a[@id='N3:Fndcpadvreqdetails:0']"), "Details");
						
						//back to req
						click(By.xpath("//a[@id='ReturnToRequests']"), "back");
						
						click(By.xpath("//a[@id='N3:item111:0']//img"), "Republish");
						
						type(By.xpath("//input[@id='Fndcplayformatname']"), "EXCEL");
						
						click(By.xpath("//button[@id='SaveButton_uixr']"), "Apply");
						
						click(By.xpath("//button[@id='OKButton']"), "Ok");
						
						// Block for validation of Phase status and Output
						if (getDriver().findElements(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']")).size() > 0) {
							String Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
									.getAttribute("textContent");
							boolean flag = false;
							while (!flag) {
								if (Phse == null) {
									getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									getDriver().findElement(By.id("Refresh_uixr")).click();
									Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
											.getAttribute("textContent");
								} else if (Phse.contains("Completed")) {
									System.out.println(Phse);
									flag = true;
									break;
								} else {
									getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
									getDriver().findElement(By.id("Refresh_uixr")).click();
									Phse = getDriver().findElement(By.xpath("//span[@id='N3:Fndcpadvreqphase:0']"))
											.getAttribute("textContent");
								}
							}
						}
						waitForElement(By.xpath("//a[@id='N3:item1212:0']//img"));
						click(By.xpath("//a[@id='N3:item1212:0']//img"), "Output flle");

						getDriver().findElement(By.id("Refresh_uixr")).click();
						getDriver().manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
						
						System.out.println("==================Test case completed==================");
		}
		
		
		@AfterMethod
		public void PDFValidate()  {
			try {
				File dir = new File("Y:\\Abhipsa");
				File[] files = dir.listFiles();
				if (files == null || files.length == 0) {
					System.out.println("There is no file in the folder");
				}

				File lastModifiedFile = files[0];
				for (int a = 1; a < files.length; a++) {
					if (lastModifiedFile.lastModified() < files[a].lastModified()) {
						lastModifiedFile = files[a];
					}
				}
				String k = lastModifiedFile.toString();
				System.out.println(lastModifiedFile);
				Path p = Paths.get(k);
				String file = p.getFileName().toString();
				System.out.println(file);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		@AfterTest
		public void Testclosure() {
			System.out.println("Test Execution is completed");
		}

		@AfterSuite
		public void closebrowser() {

			getDriver().close();

		}

}
