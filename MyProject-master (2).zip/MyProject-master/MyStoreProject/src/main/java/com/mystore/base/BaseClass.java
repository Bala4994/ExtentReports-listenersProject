package com.mystore.base;

import static org.testng.Assert.fail;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.xml.DOMConfigurator;
import org.ietf.jgss.Oid;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;

import com.beust.jcommander.Parameter;
import com.mystore.actiondriver.Action;
import com.mystore.utility.ExtentManager;

import io.github.bonigarcia.wdm.WebDriverManager;
/**
 * @author Hitendra: BaseClass is used to load the config file and Initialize 
 * WebDriver
 *  
 */
public class BaseClass {
	public static Properties prop;

	// Declare ThreadLocal Driver
	public static ThreadLocal<RemoteWebDriver> driver = new ThreadLocal<>();

	//loadConfig method is to load the configuration
	@BeforeSuite(groups = { "Smoke", "Sanity", "Regression" })
	public void loadConfig() {
		ExtentManager.setExtent();
		DOMConfigurator.configure("log4j.xml");

		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream(
					System.getProperty("user.dir") + "\\Configuration\\config.properties");
			prop.load(ip);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static WebDriver getDriver() {
		// Get Driver from threadLocalmap
		return driver.get();
	}

	public void launchApp(String browserName) {
		// String browserName = prop.getProperty("browser");
		if (browserName.equalsIgnoreCase("Chrome")) {
			WebDriverManager.chromedriver().setup();
			// Set Browser to ThreadLocalMap
			driver.set(new ChromeDriver());
		} else if (browserName.equalsIgnoreCase("FireFox")) {
			WebDriverManager.firefoxdriver().setup();
			driver.set(new FirefoxDriver());
		} else if (browserName.equalsIgnoreCase("IE")) {
			WebDriverManager.iedriver().setup();
			driver.set(new InternetExplorerDriver());
		}
		//Maximize the screen
		getDriver().manage().window().maximize();
		//Delete all the cookies
		getDriver().manage().deleteAllCookies();
		//Implicit TimeOuts
		getDriver().manage().timeouts().implicitlyWait
		(Integer.parseInt(prop.getProperty("implicitWait")),TimeUnit.SECONDS);
		//PageLoad TimeOuts
		getDriver().manage().timeouts().pageLoadTimeout
		(Integer.parseInt(prop.getProperty("pageLoadTimeOut")),TimeUnit.SECONDS);
		//Launching the URL
		//getDriver().get(prop.getProperty("url"));
	}

	@AfterSuite(groups = { "Smoke", "Regression","Sanity" })
	public void afterSuite() {
		ExtentManager.endReport();
	}
	
	public boolean scrolltoObject(By by, String locator) {
		Exception e1 = null;
		boolean flag = false;
		try {
			JavascriptExecutor js = (JavascriptExecutor) getDriver();
			int yPosition = getDriver().findElement(by).getLocation().getY();
			js.executeScript(new StringBuilder().append("window.scroll(300,")
					.append(yPosition - getDriver().manage().window().getSize().getHeight() / 2).append(")").toString(),
					new Object[0]);
			flag = true;
		} catch (Exception e) {
			e1 = e;
			flag = false;
		} finally {
			System.out.println("Scrolling to Object " + flag);
		}
		return flag;

	}

	public boolean waitForElement(By by) {
		try {
			// WebDriverWait wait = new WebDriverWait(getDriver(),
			// Integer.parseInt(getProperty("waitForElementTimeOut").trim()));
			StaticWait(1);
			System.out.println("waiting for element....");
			WebDriverWait wait = new WebDriverWait( getDriver(), 30);
			WebElement element = (WebElement) wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			System.out.println("element is displayed");
			return element.isDisplayed();
		} catch (Exception e) {
			StaticWait(2);
			//waitForPageLoad(5);
			try {
				WebDriverWait wait = new WebDriverWait( getDriver(), 30);
				WebElement element = (WebElement) wait.until(ExpectedConditions.visibilityOfElementLocated(by));
				System.out.println("element is displayed");
				return element.isDisplayed();
			} catch (Exception localException1) {
				System.out.println("element is not displayed");
			}

		}
		return false;
	}

	public String  getText(By locator) {
		String text="";
		try {
			waitForElement(locator);
			text=getDriver().findElement(locator).getText();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return text;
	}
	
	public void getAttrbute(By locator) {
		try {
			getDriver().findElement(locator).getAttribute("textContent");
		} catch (Exception e) {
			getDriver().findElement(locator).getAttribute("value");
		}
	}
	
	public void waitForPageLoad(int seconds) {
		try {
			// if (getProperty("PageLoadStrategy").equalsIgnoreCase("none"))
			for (int i = 0; (i < seconds) && ((((Long) ((JavascriptExecutor) getDriver()).executeScript("return jQuery.active", new Object[0])).longValue() != 0L)
					|| (!((JavascriptExecutor) getDriver()).executeScript("return document.readyState", new Object[0])
							.toString().equals("complete"))); i++) {
				Thread.sleep(1000L);
			}
		} catch (Exception localException) {
		}
	}

	
	public boolean waitForPageLoad() {

		return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("loaded")
	            || ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
	}

	public boolean click(By locator, String locatorName) {
		boolean flag = false;

			try {
				waitForElement(locator);
				try {
					getDriver().findElement(locator).click();
					System.out.println("Click performed on "+locatorName);
				} catch (TimeoutException localTimeoutException) {
				} catch (ElementClickInterceptedException e) {

					try {
						getDriver().findElement(locator).click();
						System.out.println("Click performed on "+locatorName);
						flag = true;
					} catch (Exception e2) {
						System.out.println("Click not performed on "+locatorName);
						flag = false;
					}
				}
				flag = true;

			} catch (Exception e) {

			}
		return flag;
	}
	
	public void type(By by, String name) {
		StaticWait(2);
		try {
			waitForElement(by);
			getDriver().findElement(by).clear();
			getDriver().findElement(by).sendKeys(name);
			tab(by);
			System.out.println("Entered data "+name);
		} catch (Exception e) {
			System.out.println("Unable to enter data"+name);
		}
	}
	
	public void tab(By by) {
		try {
			getDriver().findElement(by).sendKeys(Keys.TAB);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void tab() {
		try {
			Robot robot = new Robot();
			// Simulate key Events
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void impWait(int i) {
		getDriver().manage().timeouts().implicitlyWait(i, TimeUnit.SECONDS);
	}
	
	public void StaticWait(int i)
	         {
	           try
	           {
	          Thread.sleep(i * 1000);
	           }
	           catch (Exception localException)
	           {
	           }
	         }
	
public void validatingExpectedValue(String expected, String actual, String value) {
	if(actual.contains(expected)) {
	     Reporter.log(""+value+" Values are matching as expected i.e Expected Value is "+expected +"," +" Actual Value is "+actual);	
	} else {
		Reporter.log("Values are not matching with expected--- "+expected);
		fail(value);
	}
	}
	

}
