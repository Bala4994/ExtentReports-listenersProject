package com.mystore.testcases;

import java.awt.Desktop;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;

import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.mystore.base.BaseClass;
import com.mystore.utility.ExtentManager;
import com.mystore.utility.Log;


@Listeners(com.mystore.utility.ListenerClass.class)

public class login extends BaseClass{
	
	public WebDriver driver;
	public BaseClass action;
	
	@BeforeSuite
	public void setUp() throws Exception {
		//ExtentReport.startReport();
		driver = getDriver();
		launchApp("Chrome");	
	}
	
	
	@Test(priority=1)
	public void login1()  {
	//ExtentTest test = ExtentManager.extent.createTest("login1").assignCategory("Google");
	ExtentTest test = ExtentManager.extent.createTest("logincase1");
	Log.info("Gmail opened");
	getDriver().get("https://www.gmail.com");
	test.log(Status.INFO, "Gmail opened");
	getDriver().get("https://www.youtube.com");
	Log.info("YT opened");
	test.log(Status.INFO, "Youtube opened");
	}
	
	@Test(priority=2)
	public void login2()  {
	ExtentManager.test.assignCategory("FK");
	getDriver().get("https://www.flipkart.com");
	Log.info("FK opened");
	ExtentManager.test.log(Status.INFO, "FK opened");
	
	}
	
	@Test(priority=3)
	public void login3()  {
	ExtentManager.test.assignCategory("fb");
	getDriver().get("https://www.facebook.com");
	Log.info("FK opened");
	ExtentManager.test.log(Status.INFO, "FB");
	
	
	}
	

	@AfterSuite
	public void tearDown() throws Exception {
		Desktop.getDesktop().browse(new File("test-output/ExtentReport/MyReport.html").toURI());
	}
	
	@AfterClass
	public void close() throws IOException {
		getDriver().close();
		
	}
	
	public String getScreenshotPath() throws Exception {
		File source= ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		String path=System.getProperty("user.dir")+"/Screenshots/image.png";
		FileUtils.copyFile(source, new File(path));
		return path;
	}
	
	public String getScreenshotasBase64() throws Exception {
		File source= ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		String path=System.getProperty("user.dir")+"/Screenshots/image.png";
		FileUtils.copyFile(source, new File(path));
		byte[] imageBytes = IOUtils.toByteArray(new FileInputStream(path));
		
		return Base64.getEncoder().encodeToString(imageBytes);
	}
	
	public String getScrnshtasBase64() {
		return ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.BASE64);
	}
	
}